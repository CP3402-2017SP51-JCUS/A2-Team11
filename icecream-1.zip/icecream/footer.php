<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package icecream
 */

?>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
</div> 
<div style="background-color: #d7e0ed">
    <b>IceCreamToGo</b> - Your favorite icecream, everywhere and fast!
</footer><!-- #colophon -->
                <center>Copyright 2017 by Robert</center>
</div><!-- #page -->

<?php wp_footer(); ?>
</div>

</body>
</html>
